create database DB_L5_140922 
use DB_L5_140922

create table Library
(
id int primary key identity,
bookname varchar(100),
price int,
author varchar(100)
)
select * from Library


